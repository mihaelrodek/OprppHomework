package hr.fer.oprpp1.custom.scripting.elems;

/**
 * Class that represents an element.
 *
 * @author Mihael Rodek
 */
public class Element {

    /**
     * Method that returns element as string
     *
     * @return element as string
     */
    public String asText() {
        return "";
    }

}
