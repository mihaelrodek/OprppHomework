package hr.fer.oprpp1.custom.scripting.lexer;

public enum SmartScriptTokenType {
    TAG_START, TAG_NAME, TAG_END, TEXT, STRING, INTEGER, DOUBLE, OPERATOR, VARIABLE, FUNCTION, EOF
}
