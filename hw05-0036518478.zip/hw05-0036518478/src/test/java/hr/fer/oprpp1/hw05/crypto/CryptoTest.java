package hr.fer.oprpp1.hw05.crypto;

import org.junit.jupiter.api.Test;

import java.util.Scanner;

import static org.junit.jupiter.api.Assertions.*;

public class CryptoTest {


}
