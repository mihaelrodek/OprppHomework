
package hr.fer.zemris.java.fractals;

import hr.fer.zemris.java.fractals.mandelbrot.Mandelbrot;
import hr.fer.zemris.java.fractals.viewer.FractalViewer;
import hr.fer.zemris.java.fractals.viewer.IFractalProducer;
import hr.fer.zemris.java.fractals.viewer.IFractalResultObserver;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Class that represents parallel implementation of Mandelbrot fractal using Newton-Raphson iteration
 */
public class NewtonParallel {

    public static void main(String[] args) {
        String workersRegex = "\\-\\-workers=\\d+";
        String threadsRegex = "\\-\\-tracks=\\d+";
        Pattern pattern = Pattern.compile(workersRegex + threadsRegex, Pattern.CASE_INSENSITIVE);
        Matcher matcher1 = pattern.matcher(args[0]);
        Matcher matcher2 = pattern.matcher(args[1]);

        String prvi = args[0].replace("--workers=", "");
        prvi = args[0].replace("-w=", "");
        String drugi = args[1].replace("-tracks=", "");
        drugi = args[1].replace("-t=", "");

        //working only for 2 10 instead of -w=2 -t=10, had no time to implement it
        FractalViewer.show(new MojProducer(args[0], args[1]));
    }

    public static class PosaoIzracuna implements Runnable {
        double reMin;
        double reMax;
        double imMin;
        double imMax;
        int width;
        int height;
        int yMin;
        int yMax;
        int m;
        short[] data;
        AtomicBoolean cancel;
        double threshold;
        double rootThreshold;
        public static PosaoIzracuna NO_JOB = new PosaoIzracuna();

        public PosaoIzracuna(double reMin, double reMax, double imMin,
                             double imMax, int width, int height, int yMin, int yMax,
                             int m, short[] data, AtomicBoolean cancel) {
            super();
            this.reMin = reMin;
            this.reMax = reMax;
            this.imMin = imMin;
            this.imMax = imMax;
            this.width = width;
            this.height = height;
            this.yMin = yMin;
            this.yMax = yMax;
            this.m = m;
            this.data = data;
            this.cancel = cancel;
            this.threshold = 0.001;
            this.rootThreshold = 0.002;
        }

        public PosaoIzracuna() {

        }

        @Override
        public void run() {

            Mandelbrot.calculate(reMin, reMax, imMin, imMax, width, height, m, yMin, yMax, data, cancel);
        }
    }

    public static class MojProducer implements IFractalProducer {

        int tracks = -1;
        int workers;

        public MojProducer(String workers, String tracks) {
            this.workers = Integer.parseInt(workers);
            this.tracks = Integer.parseInt(tracks);
        }

        @Override
        public void produce(double reMin, double reMax, double imMin, double imMax,
                            int width, int height, long requestNo, IFractalResultObserver observer, AtomicBoolean cancel) {

            System.out.println("Zapocinjem izracun...");


            int maxIter = 16 * 16 * 16;
            int jobCount = 4 * Runtime.getRuntime().availableProcessors();
            int yTracks = height / jobCount;

            if (tracks == -1) {
                tracks = jobCount;
            } else if (tracks > yTracks) {
                tracks = yTracks;
            }
            short[] data = new short[width * height];

            final BlockingQueue<PosaoIzracuna> queue = new LinkedBlockingQueue<>();

            Thread[] radnici = new Thread[workers];
            for (int i = 0; i < radnici.length; i++) {
                radnici[i] = new Thread(() -> {
                    while (true) {
                        PosaoIzracuna p;
                        try {
                            p = queue.take();
                            if (p == PosaoIzracuna.NO_JOB) break;
                        } catch (InterruptedException e) {
                            continue;
                        }
                        p.run();
                    }
                });
            }

            for (int i = 0; i < radnici.length; i++) {
                radnici[i].start();
            }

            for (int i = 0; i < tracks; i++) {
                int yMin = i * yTracks;
                int yMax = (i + 1) * yTracks - 1;
                if (i == tracks - 1) {
                    yMax = height - 1;
                }
                PosaoIzracuna posao = new PosaoIzracuna(reMin, reMax, imMin, imMax, width, height, yMin, yMax, maxIter, data, cancel);
                while (true) {
                    try {
                        queue.put(posao);
                        break;
                    } catch (InterruptedException e) {
                    }
                }
            }
            for (int i = 0; i < radnici.length; i++) {
                while (true) {
                    try {
                        queue.put(PosaoIzracuna.NO_JOB);
                        break;
                    } catch (InterruptedException e) {
                    }
                }
            }

            for (int i = 0; i < radnici.length; i++) {
                while (true) {
                    try {
                        radnici[i].join();
                        break;
                    } catch (InterruptedException e) {
                    }
                }
            }

            System.out.println("Racunanje gotovo. Idem obavijestiti promatraca tj. GUI!");
            observer.acceptResult(data, (short) maxIter, requestNo);

        }


    }
}

